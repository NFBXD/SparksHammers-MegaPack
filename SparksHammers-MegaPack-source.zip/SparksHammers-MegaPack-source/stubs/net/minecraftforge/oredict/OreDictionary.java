package net.minecraftforge.oredict; public class OreDictionary { public static final int WILDCARD_VALUE = 32767; }
