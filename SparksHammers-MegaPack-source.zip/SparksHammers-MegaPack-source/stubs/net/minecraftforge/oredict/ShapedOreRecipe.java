package net.minecraftforge.oredict; import net.minecraft.item.*; public class ShapedOreRecipe implements net.minecraft.item.crafting.IRecipe { public ShapedOreRecipe(ItemStack o,Object... p){} }
