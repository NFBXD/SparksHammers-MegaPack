package net.minecraftforge.event.world;
public class BlockEvent { public static class HarvestDropsEvent extends BlockEvent {
  public final net.minecraft.entity.player.EntityPlayer harvester = null; public final java.util.ArrayList<net.minecraft.item.ItemStack> drops = null; } }
