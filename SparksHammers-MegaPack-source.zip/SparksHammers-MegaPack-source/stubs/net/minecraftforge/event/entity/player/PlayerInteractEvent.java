package net.minecraftforge.event.entity.player;
public class PlayerInteractEvent { public enum Action { RIGHT_CLICK_AIR, RIGHT_CLICK_BLOCK, LEFT_CLICK_BLOCK }
  public final Action action = null; public final int x=0,y=0,z=0,face=0; public final net.minecraft.entity.player.EntityPlayer entityPlayer = null; }
