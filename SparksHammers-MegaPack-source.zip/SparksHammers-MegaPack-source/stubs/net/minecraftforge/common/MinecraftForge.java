package net.minecraftforge.common; public class MinecraftForge { public static final cpw.mods.fml.common.eventhandler.EventBus EVENT_BUS = new cpw.mods.fml.common.eventhandler.EventBus(); }
