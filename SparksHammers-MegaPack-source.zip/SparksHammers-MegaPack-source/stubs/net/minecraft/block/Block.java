package net.minecraft.block; public class Block { public net.minecraft.block.material.Material func_149688_o(){return null;} }
