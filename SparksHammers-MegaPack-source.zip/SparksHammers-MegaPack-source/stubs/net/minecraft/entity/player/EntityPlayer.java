package net.minecraft.entity.player;
public class EntityPlayer { public net.minecraft.world.World field_70170_p; public PlayerCapabilities field_71075_bZ;
  public net.minecraft.item.ItemStack func_71045_bC(){return null;} }
