package net.minecraft.entity.player;
public class EntityPlayer extends net.minecraft.entity.Entity { public net.minecraft.world.World field_70170_p; public PlayerCapabilities field_71075_bZ; public InventoryPlayer field_71071_by;
  public net.minecraft.item.ItemStack func_71045_bC(){return null;} }
