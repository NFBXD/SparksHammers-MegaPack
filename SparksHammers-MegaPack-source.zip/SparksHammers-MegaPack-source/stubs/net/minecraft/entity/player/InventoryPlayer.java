package net.minecraft.entity.player;
public class InventoryPlayer { public boolean func_70441_a(net.minecraft.item.ItemStack s){return false;} }
