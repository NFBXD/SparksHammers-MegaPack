package net.minecraft.enchantment;
public class Enchantment { public final int field_77352_x = 0;
  protected Enchantment(int id,int weight,EnumEnchantmentType t){} public String func_77320_a(){return "";} }
