package net.minecraft.enchantment;
public enum EnumEnchantmentType { all, armor, weapon, digger, bow }
