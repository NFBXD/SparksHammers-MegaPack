package net.minecraft.enchantment; public class EnchantmentHelper { public static int func_77506_a(int id, net.minecraft.item.ItemStack s){return 0;} }
