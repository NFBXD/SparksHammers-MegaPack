package net.minecraft.init; public class Blocks { public static net.minecraft.block.Block field_150357_h; }
