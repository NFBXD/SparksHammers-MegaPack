package net.minecraft.util; public class MovingObjectPosition { public int field_72310_e; }
