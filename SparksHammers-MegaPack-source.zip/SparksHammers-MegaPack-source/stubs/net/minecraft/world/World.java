package net.minecraft.world;
public class World { public boolean field_72995_K; public net.minecraft.block.Block func_147439_a(int x,int y,int z){return null;} public boolean func_147480_a(int x,int y,int z,boolean d){return false;} }
