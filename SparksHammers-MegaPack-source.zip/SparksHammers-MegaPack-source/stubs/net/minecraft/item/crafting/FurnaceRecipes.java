package net.minecraft.item.crafting;
public class FurnaceRecipes { public static FurnaceRecipes func_77602_a(){return null;} public net.minecraft.item.ItemStack func_151395_a(net.minecraft.item.ItemStack s){return null;} }
