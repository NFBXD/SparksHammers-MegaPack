package net.minecraft.item; public class ItemTool extends Item { protected float field_77864_a; }
