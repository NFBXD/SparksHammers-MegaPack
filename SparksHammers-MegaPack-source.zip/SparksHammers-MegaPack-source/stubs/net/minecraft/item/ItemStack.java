package net.minecraft.item;
public class ItemStack { public int field_77994_a; public ItemStack(Item i){} public ItemStack(Item i,int a,int b){} public Item func_77973_b(){return null;} public ItemStack func_77946_l(){return null;} }
