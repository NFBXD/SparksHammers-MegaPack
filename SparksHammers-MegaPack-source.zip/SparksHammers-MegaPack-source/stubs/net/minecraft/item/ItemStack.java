package net.minecraft.item;
public class ItemStack { public int field_77994_a; public ItemStack(Item i){} public ItemStack(Item i,int a,int b){} public Item func_77973_b(){return null;} public ItemStack func_77946_l(){return null;}
  public net.minecraft.nbt.NBTTagCompound func_77978_p(){return null;} public void func_77982_d(net.minecraft.nbt.NBTTagCompound t){}
  public net.minecraft.nbt.NBTTagCompound func_77955_b(net.minecraft.nbt.NBTTagCompound t){return t;} public static ItemStack func_77949_a(net.minecraft.nbt.NBTTagCompound t){return null;} }
