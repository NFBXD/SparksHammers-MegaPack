package net.minecraft.item; public class ItemStack { public ItemStack(Item i){} public ItemStack(Item i,int a,int b){} public Item func_77973_b(){return null;} }
