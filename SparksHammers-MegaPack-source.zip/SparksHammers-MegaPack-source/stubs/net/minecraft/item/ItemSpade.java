package net.minecraft.item; public class ItemSpade extends ItemTool {}
