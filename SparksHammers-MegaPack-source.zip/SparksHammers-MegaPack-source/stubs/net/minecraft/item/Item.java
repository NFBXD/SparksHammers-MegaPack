package net.minecraft.item;
public class Item { public enum ToolMaterial { WOOD, STONE, IRON, EMERALD, GOLD }
  public float func_150893_a(ItemStack s, net.minecraft.block.Block b){return 0;}
  public boolean func_150897_b(net.minecraft.block.Block b){return false;} }
