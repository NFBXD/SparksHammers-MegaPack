package net.minecraft.item;
public class Item { public enum ToolMaterial { WOOD, STONE, IRON, EMERALD, GOLD }
  public float func_150893_a(ItemStack s, net.minecraft.block.Block b){return 0;}
  public boolean func_150897_b(net.minecraft.block.Block b){return false;}
  public Item func_77655_b(String n){return this;} public Item func_111206_d(String n){return this;} public Item func_77625_d(int n){return this;}
  public Item func_77637_a(net.minecraft.creativetab.CreativeTabs t){return this;}
  public ItemStack func_77659_a(ItemStack s, net.minecraft.world.World w, net.minecraft.entity.player.EntityPlayer p){return s;} }
