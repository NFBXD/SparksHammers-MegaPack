package net.minecraft.nbt;
public class NBTTagCompound extends NBTBase { public void func_74774_a(String k, byte v){} public byte func_74771_c(String k){return 0;}
  public void func_74782_a(String k, NBTBase v){} public NBTTagList func_150295_c(String k,int t){return null;} }
