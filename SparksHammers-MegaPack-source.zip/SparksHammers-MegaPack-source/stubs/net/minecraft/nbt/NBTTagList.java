package net.minecraft.nbt;
public class NBTTagList extends NBTBase { public void func_74742_a(NBTBase b){} public int func_74745_c(){return 0;} public NBTTagCompound func_150305_b(int i){return null;} }
