package cpw.mods.fml.common.eventhandler;
public class EventBus { public void register(Object o){} }
