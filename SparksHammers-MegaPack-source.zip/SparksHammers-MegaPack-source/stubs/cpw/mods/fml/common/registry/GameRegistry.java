package cpw.mods.fml.common.registry;
import net.minecraft.item.*; import net.minecraft.item.crafting.IRecipe;
public class GameRegistry { public static void registerItem(Item i,String n){} public static Item findItem(String m,String n){return null;} public static void addRecipe(IRecipe r){} }
