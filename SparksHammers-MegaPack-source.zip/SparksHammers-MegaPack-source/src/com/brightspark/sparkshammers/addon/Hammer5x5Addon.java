/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.addon;

import com.brightspark.sparkshammers.item.ItemBedrockExcavator;
import com.brightspark.sparkshammers.item.ItemBedrockHammer;
import com.brightspark.sparkshammers.item.ItemDeepExcavator;
import com.brightspark.sparkshammers.item.ItemDeepHammer;
import com.brightspark.sparkshammers.item.ItemExcavator;
import com.brightspark.sparkshammers.item.ItemExcavatorSized;
import com.brightspark.sparkshammers.item.ItemHammer;
import com.brightspark.sparkshammers.item.ItemHammer5x5;
import com.brightspark.sparkshammers.item.ItemHammerExcavator;
import com.brightspark.sparkshammers.item.ItemUniversalExcavator;
import com.brightspark.sparkshammers.item.ItemUniversalHammer;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.oredict.ShapedOreRecipe;
import net.minecraftforge.oredict.ShapelessOreRecipe;

@Mod(modid = "SparksHammers5x5", name = "Spark's Hammers 5x5 Addon", version = "1.2", dependencies = "required-after:SparksHammers")
public class Hammer5x5Addon {
    // id, block registry name, block meta, harvest level, durability, efficiency, damage, enchantability
    private static final Object[][] MATERIALS = {
        {"Obsidian",    "obsidian",          0, 3, 2500, 8.0f, 3.0f, 5},
        {"StoneBrick",  "stonebrick",        0, 1,  220, 4.0f, 1.0f, 5},
        {"MossyCobble", "mossy_cobblestone", 0, 1,  150, 3.5f, 1.0f, 5},
        {"PlankOak",    "planks",            0, 0,   60, 2.0f, 0.0f, 15},
        {"PlankSpruce", "planks",            1, 0,   60, 2.0f, 0.0f, 15},
        {"PlankBirch",  "planks",            2, 0,   60, 2.0f, 0.0f, 15},
        {"PlankAcacia", "planks",            4, 0,   60, 2.0f, 0.0f, 15},
        {"PlankDarkOak","planks",            5, 0,   60, 2.0f, 0.0f, 15},
        {"Brick",       "brick_block",       0, 1,  180, 4.0f, 1.0f, 5},
        {"Netherrack",  "netherrack",        0, 1,  120, 3.5f, 1.0f, 8},
    };

    private static Item netherStar;
    private static Item bedrock;

    private static ItemStack any(Item item) {
        return new ItemStack(item, 1, OreDictionary.WILDCARD_VALUE);
    }

    private static void recipe(Item result, Object... in) {
        GameRegistry.addRecipe(new ShapelessOreRecipe(new ItemStack(result), in));
    }

    /** Infinite version: Nether Stars in corners, Bedrock on edges, the normal tool in the centre. */
    private static void infRecipe(Item result, Item center) {
        if (netherStar == null || bedrock == null || center == null) return;
        GameRegistry.addRecipe(new ShapedOreRecipe(new ItemStack(result), "NBN", "BDB", "NBN",
            'N', new ItemStack(netherStar), 'B', new ItemStack(bedrock), 'D', any(center)));
    }

    private static void bedrockRecipe(Item result, Item center) {
        GameRegistry.addRecipe(new ShapedOreRecipe(new ItemStack(result), "BBB", "BDB", "BBB",
            'B', new ItemStack(bedrock), 'D', any(center)));
    }

    private static void reg(Item item, String id) {
        GameRegistry.registerItem(item, id);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Item diamondHammer = GameRegistry.findItem("SparksHammers", "hammerDiamond");
        Item diamondExcavator = GameRegistry.findItem("SparksHammers", "excavatorDiamond");
        netherStar = GameRegistry.findItem("minecraft", "nether_star");
        bedrock = GameRegistry.findItem("minecraft", "bedrock");
        Item.ToolMaterial dia = Item.ToolMaterial.EMERALD;

        // 3x3 hybrid: Diamond Hammer + Diamond Excavator
        ItemHammerExcavator combo3 = new ItemHammerExcavator("hammerExcavator3x3", dia, 1);
        reg(combo3, "hammerExcavator3x3");
        if (diamondHammer != null && diamondExcavator != null) recipe(combo3, any(diamondHammer), any(diamondExcavator));

        // Deep tools: 3x3 face, 3 blocks deep (3x3x3). Diamond tool + Diamond Block.
        ItemDeepHammer deepHammer = new ItemDeepHammer("hammerDeep", dia, 1, 2);
        reg(deepHammer, "hammerDeep");
        if (diamondHammer != null) recipe(deepHammer, any(diamondHammer), "blockDiamond");
        ItemDeepExcavator deepExcavator = new ItemDeepExcavator("excavatorDeep", dia, 1, 2);
        reg(deepExcavator, "excavatorDeep");
        if (diamondExcavator != null) recipe(deepExcavator, any(diamondExcavator), "blockDiamond");

        // Universal (any block material) 3x3 tools: Diamond tool + Nether Star
        Item uHammer = new ItemUniversalHammer("hammerAny", dia);
        reg(uHammer, "hammerAny");
        if (diamondHammer != null && netherStar != null) recipe(uHammer, any(diamondHammer), new ItemStack(netherStar));
        Item uExcavator = new ItemUniversalExcavator("excavatorAny", dia);
        reg(uExcavator, "excavatorAny");
        if (diamondExcavator != null && netherStar != null) recipe(uExcavator, any(diamondExcavator), new ItemStack(netherStar));

        // Infinite universal tools (star icon)
        ItemUniversalHammer iHammer = new ItemUniversalHammer("hammerInfinite", dia);
        iHammer.setInfinite(true);
        reg(iHammer, "hammerInfinite");
        infRecipe(iHammer, diamondHammer);
        ItemUniversalExcavator iExcavator = new ItemUniversalExcavator("excavatorInfinite", dia);
        iExcavator.setInfinite(true);
        reg(iExcavator, "excavatorInfinite");
        infRecipe(iExcavator, diamondExcavator);

        // Infinite regular hammer and infinite 3x3 hybrid
        ItemHammer iBasic = new ItemHammer("hammerInfiniteBasic", dia);
        iBasic.setInfinite(true);
        reg(iBasic, "hammerInfiniteBasic");
        infRecipe(iBasic, diamondHammer);
        ItemHammerExcavator iCombo = new ItemHammerExcavator("hammerExcavatorInfinite", dia, 1);
        iCombo.setInfinite(true);
        reg(iCombo, "hammerExcavatorInfinite");
        infRecipe(iCombo, combo3);

        // Bedrock tools (3x3, infinite, universal, can break bedrock): infinite tool in the centre, 8 Bedrock around
        MinecraftForge.EVENT_BUS.register(new BedrockBreakHandler());
        ItemBedrockHammer bHammer = new ItemBedrockHammer("hammerBedrock", dia);
        reg(bHammer, "hammerBedrock");
        ItemBedrockExcavator bExcavator = new ItemBedrockExcavator("excavatorBedrock", dia);
        reg(bExcavator, "excavatorBedrock");
        ItemBedrockHammer bCombo = new ItemBedrockHammer("hammerExcavatorBedrock", dia);
        reg(bCombo, "hammerExcavatorBedrock");
        if (bedrock != null) {
            bedrockRecipe(bHammer, iHammer);
            bedrockRecipe(bExcavator, iExcavator);
            bedrockRecipe(bCombo, iCombo);
        }

        // Sizes 5x5 ... 17x17: hammer, excavator, hybrid; each with a normal and an infinite version.
        // hammer N = previous hammer + 2 Diamond Blocks, excavator N = previous excavator + 2 Diamond Blocks,
        // hybrid N = hammer N + Diamond Excavator, infinite = Nether Star / Bedrock ring around the normal tool.
        Item prevH = diamondHammer;
        Item prevE = diamondExcavator;
        for (int size = 5; size <= 17; size += 2) {
            int radius = (size - 1) / 2;
            String sz = size + "x" + size;
            String hn = "hammer" + sz;
            String en = "excavator" + sz;
            String cn = size == 5 ? "hammerExcavator" : "hammerExcavator" + sz;

            ItemHammer5x5 h = new ItemHammer5x5(hn, dia, radius);
            reg(h, hn);
            if (prevH != null) recipe(h, any(prevH), "blockDiamond", "blockDiamond");
            ItemExcavatorSized e = new ItemExcavatorSized(en, dia, radius);
            reg(e, en);
            if (prevE != null) recipe(e, any(prevE), "blockDiamond", "blockDiamond");
            ItemHammerExcavator c = new ItemHammerExcavator(cn, dia, radius);
            reg(c, cn);
            if (diamondExcavator != null) recipe(c, any(h), any(diamondExcavator));

            ItemHammer5x5 hi = new ItemHammer5x5(hn + "Inf", dia, radius);
            hi.setInfinite(true);
            reg(hi, hn + "Inf");
            infRecipe(hi, h);
            ItemExcavatorSized ei = new ItemExcavatorSized(en + "Inf", dia, radius);
            ei.setInfinite(true);
            reg(ei, en + "Inf");
            infRecipe(ei, e);
            ItemHammerExcavator ci = new ItemHammerExcavator(size == 5 ? "hammerExcavator5x5Inf" : cn + "Inf", dia, radius);
            ci.setInfinite(true);
            reg(ci, size == 5 ? "hammerExcavator5x5Inf" : cn + "Inf");
            infRecipe(ci, c);

            prevH = h;
            prevE = e;
        }

        // Material tools (3x3): hammer, excavator, hybrid; normal and infinite.
        for (Object[] m : MATERIALS) {
            String id = (String) m[0];
            Item block = GameRegistry.findItem("minecraft", (String) m[1]);
            Item.ToolMaterial mat = EnumHelper.addToolMaterial("SH_" + id, (Integer) m[3], (Integer) m[4],
                (Float) m[5], (Float) m[6], (Integer) m[7]);
            ItemHammer hammer = new ItemHammer("hammer" + id, mat);
            ItemExcavator excavator = new ItemExcavator("excavator" + id, mat);
            ItemHammerExcavator hybrid = new ItemHammerExcavator("hammerExcavator" + id, mat, 1);
            reg(hammer, "hammer" + id);
            reg(excavator, "excavator" + id);
            reg(hybrid, "hammerExcavator" + id);
            if (block != null) {
                ItemStack stack = new ItemStack(block, 1, (Integer) m[2]);
                GameRegistry.addRecipe(new ShapedOreRecipe(new ItemStack(hammer),
                    "MMM", "MSM", " S ", 'M', stack, 'S', "stickWood"));
                GameRegistry.addRecipe(new ShapedOreRecipe(new ItemStack(excavator),
                    "MMM", " S ", " S ", 'M', stack, 'S', "stickWood"));
            }
            recipe(hybrid, any(hammer), any(excavator));

            ItemHammer hi = new ItemHammer("hammer" + id + "Inf", mat);
            hi.setInfinite(true);
            reg(hi, "hammer" + id + "Inf");
            infRecipe(hi, hammer);
            ItemExcavator ei = new ItemExcavator("excavator" + id + "Inf", mat);
            ei.setInfinite(true);
            reg(ei, "excavator" + id + "Inf");
            infRecipe(ei, excavator);
            ItemHammerExcavator ci = new ItemHammerExcavator("hammerExcavator" + id + "Inf", mat, 1);
            ci.setInfinite(true);
            reg(ci, "hammerExcavator" + id + "Inf");
            infRecipe(ci, hybrid);
        }
    }
}
