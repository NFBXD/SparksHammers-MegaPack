/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.addon;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;

/** Simple one-level enchantment for digging tools (hammers, excavators, pickaxes, shovels...). */
public class HammerEnchantment extends Enchantment {
    private final String key;

    public HammerEnchantment(int id, String key) {
        super(id, 2, EnumEnchantmentType.digger);
        this.key = key;
    }

    /** Enchantment name (translation key "enchantment.<name>"). */
    public String func_77320_a() {
        return "enchantment." + key;
    }
}
