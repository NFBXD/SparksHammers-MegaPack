/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.addon;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

/** Left-clicking bedrock with a bedrock tool breaks it (and the bedrock around it in a 3x3 plane). */
public class BedrockBreakHandler {
    @SubscribeEvent
    public void onLeftClick(PlayerInteractEvent event) {
        if (event.action != PlayerInteractEvent.Action.LEFT_CLICK_BLOCK) return;
        EntityPlayer player = event.entityPlayer;
        World world = player.field_70170_p;
        if (world.field_72995_K) return;
        ItemStack held = player.func_71045_bC();
        if (held == null || !(held.func_77973_b() instanceof IBedrockBreaker)) return;
        Block bedrock = Blocks.field_150357_h;
        if (world.func_147439_a(event.x, event.y, event.z) != bedrock) return;
        boolean drop = !player.field_71075_bZ.field_75098_d;
        for (int a = -1; a <= 1; a++) {
            for (int b = -1; b <= 1; b++) {
                int x = event.x, y = event.y, z = event.z;
                switch (event.face) {
                    case 0: case 1: x += a; z += b; break;
                    case 2: case 3: x += a; y += b; break;
                    default: y += a; z += b; break;
                }
                if (world.func_147439_a(x, y, z) == bedrock) {
                    world.func_147480_a(x, y, z, drop);
                }
            }
        }
    }
}
