/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.addon;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraftforge.event.world.BlockEvent;

/** Applies the Smelting and Magnet enchantments to block drops. Everything is wrapped so it can never crash the game. */
public class EnchantHandler {
    public static int smeltingId = -1;
    public static int magnetId = -1;

    @SubscribeEvent
    public void onHarvest(BlockEvent.HarvestDropsEvent event) {
        try {
            EntityPlayer player = event.harvester;
            if (player == null) return;
            ItemStack tool = player.func_71045_bC();
            if (tool == null) return;
            if (smeltingId >= 0 && EnchantmentHelper.func_77506_a(smeltingId, tool) > 0) smelt(event);
            if (magnetId >= 0 && EnchantmentHelper.func_77506_a(magnetId, tool) > 0) magnet(event, player);
        } catch (Throwable ignored) {
        }
    }

    private void smelt(BlockEvent.HarvestDropsEvent event) {
        for (int i = 0; i < event.drops.size(); i++) {
            ItemStack drop = event.drops.get(i);
            if (drop == null) continue;
            ItemStack result = FurnaceRecipes.func_77602_a().func_151395_a(drop);
            if (result != null) {
                ItemStack out = result.func_77946_l();
                out.field_77994_a = result.field_77994_a * drop.field_77994_a;
                event.drops.set(i, out);
            }
        }
    }

    private void magnet(BlockEvent.HarvestDropsEvent event, EntityPlayer player) {
        for (int i = event.drops.size() - 1; i >= 0; i--) {
            ItemStack drop = event.drops.get(i);
            if (drop != null && player.field_71071_by.func_70441_a(drop.func_77946_l())) {
                event.drops.remove(i);
            }
        }
    }
}
