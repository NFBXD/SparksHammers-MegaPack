/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.addon;

import com.brightspark.sparkshammers.item.ItemExcavator;
import com.brightspark.sparkshammers.item.ItemHammer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

/** 27-slot inventory stored in the NBT of the toolbox item. Only hammers, excavators and hybrids fit. */
public class ToolboxInventory implements IInventory {
    private static final int SIZE = 27;
    private final ItemStack box;
    private final ItemStack[] slots = new ItemStack[SIZE];

    public ToolboxInventory(ItemStack box) {
        this.box = box;
        NBTTagCompound tag = box.func_77978_p();
        if (tag != null) {
            NBTTagList list = tag.func_150295_c("ToolboxItems", 10);
            for (int i = 0; i < list.func_74745_c(); i++) {
                NBTTagCompound entry = list.func_150305_b(i);
                int slot = entry.func_74771_c("Slot") & 255;
                if (slot < SIZE) slots[slot] = ItemStack.func_77949_a(entry);
            }
        }
    }

    private void save() {
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < SIZE; i++) {
            if (slots[i] != null) {
                NBTTagCompound entry = new NBTTagCompound();
                entry.func_74774_a("Slot", (byte) i);
                slots[i].func_77955_b(entry);
                list.func_74742_a(entry);
            }
        }
        NBTTagCompound tag = box.func_77978_p();
        if (tag == null) {
            tag = new NBTTagCompound();
            box.func_77982_d(tag);
        }
        tag.func_74782_a("ToolboxItems", list);
    }

    public int func_70302_i_() { return SIZE; }

    public ItemStack func_70301_a(int i) { return slots[i]; }

    public ItemStack func_70298_a(int i, int n) {
        if (slots[i] == null) return null;
        ItemStack out;
        if (slots[i].field_77994_a <= n) {
            out = slots[i];
            slots[i] = null;
        } else {
            out = slots[i].func_77946_l();
            out.field_77994_a = n;
            slots[i].field_77994_a -= n;
            if (slots[i].field_77994_a <= 0) slots[i] = null;
        }
        func_70296_d();
        return out;
    }

    public ItemStack func_70304_b(int i) {
        ItemStack s = slots[i];
        slots[i] = null;
        return s;
    }

    public void func_70299_a(int i, ItemStack s) {
        slots[i] = s;
        func_70296_d();
    }

    public String func_145825_b() { return "container.sparkshammers.toolbox"; }

    public boolean func_145818_k_() { return false; }

    public int func_70297_j_() { return 64; }

    public void func_70296_d() { save(); }

    public boolean func_70300_a(EntityPlayer player) { return true; }

    public void func_70295_k_() { }

    public void func_70305_f() { save(); }

    public boolean func_94041_b(int i, ItemStack s) {
        return s != null && (s.func_77973_b() instanceof ItemHammer || s.func_77973_b() instanceof ItemExcavator);
    }
}
