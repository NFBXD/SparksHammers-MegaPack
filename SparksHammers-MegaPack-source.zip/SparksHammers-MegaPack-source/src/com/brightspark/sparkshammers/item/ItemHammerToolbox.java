/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.item;

import com.brightspark.sparkshammers.SHCreativeTab;
import com.brightspark.sparkshammers.addon.ToolboxInventory;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

/** Portable box for hammers, excavators and hybrids. Right-click to open. */
public class ItemHammerToolbox extends Item {
    public ItemHammerToolbox(String name) {
        func_77655_b(name);
        func_111206_d("SparksHammers:" + name);
        func_77625_d(1);
        func_77637_a(SHCreativeTab.SH_TAB);
    }

    /** onItemRightClick */
    public ItemStack func_77659_a(ItemStack stack, World world, EntityPlayer player) {
        if (!world.field_72995_K) {
            player.func_71007_a(new ToolboxInventory(stack));
        }
        return stack;
    }
}
