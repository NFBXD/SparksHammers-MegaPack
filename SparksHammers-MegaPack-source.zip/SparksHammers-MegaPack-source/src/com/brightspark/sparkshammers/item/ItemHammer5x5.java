/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.item;

import net.minecraft.item.Item;

/** Hammer that breaks a 5x5 area (mine radius 2). */
public class ItemHammer5x5 extends ItemHammer {
    public ItemHammer5x5(String name, Item.ToolMaterial material) {
        this(name, material, 2);
    }

    public ItemHammer5x5(String name, Item.ToolMaterial material, int radius) {
        super(name, material, null, false);
        try {
            java.lang.reflect.Field f = ItemHammer.class.getDeclaredField("mineRadius");
            f.setAccessible(true);
            f.setInt(this, radius);
        } catch (Exception e) {
            throw new RuntimeException("Could not set 5x5 mine radius", e);
        }
    }
}
