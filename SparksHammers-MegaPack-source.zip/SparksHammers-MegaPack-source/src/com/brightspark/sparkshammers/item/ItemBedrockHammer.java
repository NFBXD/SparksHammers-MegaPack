/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.item;

import com.brightspark.sparkshammers.addon.IBedrockBreaker;
import net.minecraft.item.Item;

/** Infinite universal hammer that can break bedrock. */
public class ItemBedrockHammer extends ItemUniversalHammer implements IBedrockBreaker {
    public ItemBedrockHammer(String name, Item.ToolMaterial material) {
        super(name, material);
        setInfinite(true);
    }
}
