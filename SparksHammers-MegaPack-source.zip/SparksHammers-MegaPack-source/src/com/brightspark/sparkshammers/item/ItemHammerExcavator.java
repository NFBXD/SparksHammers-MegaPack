/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.item;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** tool (3x3 or 5x5) that works as both a hammer (pickaxe) and an excavator (shovel). */
public class ItemHammerExcavator extends ItemHammer {
    private static boolean isShovelMaterial(Material m) {
        return m == Material.field_151577_b || m == Material.field_151578_c || m == Material.field_151595_p
            || m == Material.field_151597_y || m == Material.field_151596_z || m == Material.field_151571_B;
    }

    public ItemHammerExcavator(String name, Item.ToolMaterial material, int radius) {
        super(name, material, null, false);
        try {
            java.lang.reflect.Field f = ItemHammer.class.getDeclaredField("mineRadius");
            f.setAccessible(true);
            f.setInt(this, radius);
        } catch (Exception e) {
            throw new RuntimeException("Could not set mine radius", e);
        }
    }

    @Override
    public boolean isEffective(Material m) {
        return super.isEffective(m) || isShovelMaterial(m);
    }

    @Override
    public float func_150893_a(ItemStack stack, Block block) {
        if (isShovelMaterial(block.func_149688_o())) return this.field_77864_a;
        return super.func_150893_a(stack, block);
    }
}
