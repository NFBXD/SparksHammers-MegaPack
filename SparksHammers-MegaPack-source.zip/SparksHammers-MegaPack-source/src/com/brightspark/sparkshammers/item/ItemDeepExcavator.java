/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.item;

import net.minecraft.item.Item;

/** Excavator that breaks a (2*radius+1)^2 area, (2*depth+1) blocks deep. */
public class ItemDeepExcavator extends ItemExcavator {
    public ItemDeepExcavator(String name, Item.ToolMaterial material, int radius, int depth) {
        super(name, material, null, false);
        try {
            java.lang.reflect.Field r = ItemExcavator.class.getDeclaredField("mineRadius");
            r.setAccessible(true);
            r.setInt(this, radius);
            java.lang.reflect.Field d = ItemExcavator.class.getDeclaredField("mineDepth");
            d.setAccessible(true);
            d.setInt(this, depth);
        } catch (Exception e) {
            throw new RuntimeException("Could not set mine radius/depth", e);
        }
    }
}
