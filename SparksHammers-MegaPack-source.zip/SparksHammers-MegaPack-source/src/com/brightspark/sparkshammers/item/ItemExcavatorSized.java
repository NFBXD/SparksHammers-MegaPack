/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.item;

import net.minecraft.item.Item;

/** Excavator with a configurable mine radius (radius 2 = 5x5, 3 = 7x7, ...). */
public class ItemExcavatorSized extends ItemExcavator {
    public ItemExcavatorSized(String name, Item.ToolMaterial material, int radius) {
        super(name, material, null, false);
        try {
            java.lang.reflect.Field f = ItemExcavator.class.getDeclaredField("mineRadius");
            f.setAccessible(true);
            f.setInt(this, radius);
        } catch (Exception e) {
            throw new RuntimeException("Could not set mine radius", e);
        }
    }
}
