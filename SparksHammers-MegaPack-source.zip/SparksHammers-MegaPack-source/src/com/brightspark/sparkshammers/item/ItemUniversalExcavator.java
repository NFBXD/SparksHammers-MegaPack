/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.item;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** Excavator (shovel-based) that is effective on every block material. */
public class ItemUniversalExcavator extends ItemExcavator {
    public ItemUniversalExcavator(String name, Item.ToolMaterial material) {
        super(name, material, null, false);
    }

    @Override
    public boolean isEffective(Material m) {
        return true;
    }

    @Override
    public float func_150893_a(ItemStack stack, Block block) {
        return this.field_77864_a;
    }

    @Override
    public boolean func_150897_b(Block block) {
        return true;
    }
}
