/*
 * Spark's Hammers Mega Pack (addon for Spark's Hammers 1.7.10)
 * Based on Spark's Hammers by Brightspark. Licensed under the GNU General Public License v2 (see LICENSE).
 */
package com.brightspark.sparkshammers.item;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

/**
 * Hammer that breaks a size x size x size cube: a size x size area on the face you hit,
 * going size blocks deep into the wall (nothing is broken in front of the face).
 */
public class ItemCubeHammer extends ItemHammer {
    private final int size;

    public ItemCubeHammer(String name, Item.ToolMaterial material, int size) {
        super(name, material, null, false);
        this.size = size;
    }

    @Override
    public boolean onBlockStartBreak(ItemStack stack, int x, int y, int z, EntityPlayer player) {
        World world = player.field_70170_p;
        Block block = world.func_147439_a(x, y, z);
        MovingObjectPosition mop = Common.raytraceFromEntity(world, player, false, 4.5D);
        if (mop == null || !isEffective(block.func_149688_o())) return false;
        int side = mop.field_72310_e;
        int r = (size - 1) / 2;
        for (int depth = 0; depth < size; depth++) {
            for (int a = -r; a <= r; a++) {
                for (int b = -r; b <= r; b++) {
                    if (depth == 0 && a == 0 && b == 0) continue;
                    int bx = x, by = y, bz = z;
                    switch (side) {
                        case 0: bx += a; bz += b; by += depth; break; // hit bottom face, dig up
                        case 1: bx += a; bz += b; by -= depth; break; // hit top face, dig down
                        case 2: bx += a; by += b; bz += depth; break; // hit north face, dig south
                        case 3: bx += a; by += b; bz -= depth; break; // hit south face, dig north
                        case 4: by += a; bz += b; bx += depth; break; // hit west face, dig east
                        default: by += a; bz += b; bx -= depth; break; // hit east face, dig west
                    }
                    breakExtraBlock(world, bx, by, bz, side, player, x, y, z);
                }
            }
        }
        return false;
    }
}
