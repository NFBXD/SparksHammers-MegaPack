#!/usr/bin/env bash
# Usage: ./build.sh path/to/SparksHammers-1.7.10-1.6.1.jar
# Needs a JDK (8 or newer), unzip, zip. Output: build/SparksHammers-MegaPack.jar
set -euo pipefail
ORIG="$(cd "$(dirname "${1:?path to the original SparksHammers jar}")" && pwd)/$(basename "$1")"
cd "$(dirname "$0")"
rm -rf build && mkdir -p build/stubs build/classes build/jar
# 1. compile the small Minecraft/Forge stubs (used only to compile, never shipped)
javac --release 8 -nowarn -d build/stubs $(find stubs -name '*.java')
# 2. compile the addon against the original mod + stubs
javac --release 8 -nowarn -d build/classes -cp "$ORIG:build/stubs" $(find src -name '*.java')
# 3. unpack the original mod, add our classes (class version 50 = Java 6, like the original) and assets
(cd build/jar && unzip -q "$ORIG")
(cd build/classes && find . -name '*.class') | while read -r f; do
  mkdir -p "build/jar/$(dirname "$f")"
  cp "build/classes/$f" "build/jar/$f"
  printf '\x00\x32' | dd of="build/jar/$f" bs=1 seek=6 conv=notrunc 2>/dev/null
done
cp -r assets build/jar/
(cd build/jar && zip -qr -X ../SparksHammers-MegaPack.jar META-INF assets com)
echo "Done: build/SparksHammers-MegaPack.jar"
